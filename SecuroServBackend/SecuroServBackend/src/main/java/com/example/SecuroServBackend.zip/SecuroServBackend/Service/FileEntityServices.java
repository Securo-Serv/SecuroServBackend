package com.example.SecuroServBackend.Service;

import com.example.SecuroServBackend.DTOs.FileEntityDTO;
import com.example.SecuroServBackend.Entity.FileEntity;
import com.example.SecuroServBackend.Repository.FileEntityRepo;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDateTime;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class FileEntityServices {

    private final FileEntityRepo fileEntityRepo;
    public FileEntity uploadFile(UUID id) {
        FileEntity fileEntity = fileEntityRepo.findById(id)
                .orElseThrow(()->new RuntimeException("File not found!"));
        FileEntityDTO fileEntityDTO = new FileEntityDTO();
        fileEntityDTO.setFileId(fileEntity.getFileId());
        fileEntityDTO.setName(fileEntity.getFileName());
        fileEntityDTO.setCreationAT(LocalDateTime.from(fileEntity.getUploadedAt()));
        fileEntityDTO.setType("file");
        return fileEntity;
    }
}
