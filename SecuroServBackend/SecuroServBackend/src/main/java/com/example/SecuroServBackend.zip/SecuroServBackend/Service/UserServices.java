package com.example.SecuroServBackend.Service;

import com.example.SecuroServBackend.DTOs.FileEntityDTO;
import com.example.SecuroServBackend.DTOs.FolderDTO;
import com.example.SecuroServBackend.DTOs.UserDTO;
import com.example.SecuroServBackend.Entity.User;

import org.springframework.stereotype.Service;

import java.time.Instant;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class UserServices {
    public UserDTO getUserVault(User user) {

        //  Map root folders (parentFolder == null)
        List<FolderDTO> folderDTOs = user.getFolders().stream()
                .filter(folder -> folder.getParentFolder() == null)
                .map(folder -> {
                    FolderDTO dto = new FolderDTO();
                    dto.setFolderId(folder.getFolderId());
                    dto.setName(folder.getName());
                    dto.setType("Folder");
                    dto.setCreationAT(LocalDateTime.now());
                    return dto;
                })
                .collect(Collectors.toList());

        //  Map root files (folder == null)
        List<FileEntityDTO> fileDTOs = user.getRootFiles().stream()
                .filter(file -> file.getFolder() == null)
                .map(file -> {
                    FileEntityDTO dto = new FileEntityDTO();
                    dto.setFileId(file.getFileId());
                    dto.setName(file.getFileName());
                    dto.setType("File");
                    dto.setCreationAT(LocalDateTime.now());
                    return dto;
                })
                .collect(Collectors.toList());

        //  Construct final vault DTO
        UserDTO vaultDTO = new UserDTO();
        vaultDTO.setUserId(user.getUserId());
        vaultDTO.setEmail(user.getAuthUser().getEmail());
        vaultDTO.setFolders(folderDTOs);
        vaultDTO.setFiles(fileDTOs);

        System.out.println(vaultDTO.toString());

        return vaultDTO;
    }
}
