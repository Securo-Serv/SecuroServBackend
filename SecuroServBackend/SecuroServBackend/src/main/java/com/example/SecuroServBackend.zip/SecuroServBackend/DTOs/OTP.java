package com.example.SecuroServBackend.DTOs;

import lombok.Data;

@Data
public class OTP {
    private String otp;
}
