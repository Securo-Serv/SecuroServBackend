package com.example.SecuroServBackend.Mappers;

public class UserMapper {

}
