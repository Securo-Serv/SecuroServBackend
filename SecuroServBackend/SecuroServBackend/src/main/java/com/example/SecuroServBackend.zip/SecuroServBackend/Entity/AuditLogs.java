package com.example.SecuroServBackend.Entity;

import jakarta.persistence.*;
import lombok.Data;

import java.time.Instant;
import java.util.UUID;

@Entity
@Data
public class AuditLogs {
    @Id
    @GeneratedValue
    @org.hibernate.annotations.UuidGenerator
    private UUID auditId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @Column(nullable = false)
    private String actionType;  // UPLOAD, DOWNLOAD, DELETE, LOGIN, etc.

    @Column(nullable = true)
    private String targetName;  // file or folder name

    @Column(nullable = true)
    private String targetType;  // FILE or FOLDER

    @Column(nullable = true)
    private String details;     // optional JSON/string details

    @Column(nullable = false)
    private Instant timestamp = Instant.now();

    @Column(nullable = true)
    private String ipAddress;

}
