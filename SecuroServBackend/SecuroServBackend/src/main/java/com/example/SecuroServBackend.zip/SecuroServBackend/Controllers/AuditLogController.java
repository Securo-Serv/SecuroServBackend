package com.example.SecuroServBackend.Controllers;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/AuditLogs")
public class AuditLogController {

}
