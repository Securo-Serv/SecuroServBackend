package com.example.SecuroServBackend.Service;

import org.springframework.stereotype.Service;

@Service
public class AuditLogServices {

}
