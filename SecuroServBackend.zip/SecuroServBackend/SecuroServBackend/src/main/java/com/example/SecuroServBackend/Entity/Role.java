package com.example.SecuroServBackend.Entity;

public enum Role {
    USER,
    PREMIUM
}
